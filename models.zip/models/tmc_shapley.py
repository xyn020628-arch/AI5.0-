# ============================================================================
# tmc_shapley.py — TMC-Shapley激励机制
# ============================================================================
# 功能：基于截断蒙特卡洛Shapley值的贡献度评估与公平收益分配
# 论文结果：
#   - Shapley值基尼系数: 0.285 (较固定方案0.487降低41.5%)
#   - 参与率: 62.3% → 87.4% (+25.1pp)
#   - 高质量提供方占比: 28.5% → 56.7%
#   - 近似误差 < 0.5% (n=100时)
# ============================================================================

import numpy as np
from typing import List, Dict, Tuple, Callable, Optional
from dataclasses import dataclass, field
from itertools import combinations, permutations
import random
import time
import warnings


# ============================================================================
# 四维度贡献评分 (CCS)
# ============================================================================

@dataclass
class ContributionScore:
    """四维度综合贡献评分 CCS (Composite Contribution Score)

    CCS = w1 * 模型质量 + w2 * 数据贡献 + w3 * 计算资源 + w4 * 信誉
    权重可动态调节以适应市场不同发展阶段
    """
    model_quality: float = 0.0    # 模型在验证集上的性能
    data_contribution: float = 0.0  # 数据量+多样性
    compute_resource: float = 0.0   # 提供的算力资源
    reputation: float = 0.0         # 历史信誉评分

    # 论文默认权重
    weights: Tuple[float, ...] = (0.40, 0.25, 0.20, 0.15)

    @property
    def score(self) -> float:
        """计算综合贡献评分"""
        return (
            self.weights[0] * self.model_quality +
            self.weights[1] * self.data_contribution +
            self.weights[2] * self.compute_resource +
            self.weights[3] * self.reputation
        )

    @classmethod
    def from_dict(cls, data: Dict[str, float],
                  weights: Optional[Tuple[float, ...]] = None) -> "ContributionScore":
        """从字典构建贡献评分"""
        instance = cls(
            model_quality=data.get("model_quality", 0.0),
            data_contribution=data.get("data_contribution", 0.0),
            compute_resource=data.get("compute_resource", 0.0),
            reputation=data.get("reputation", 0.0),
        )
        if weights:
            instance.weights = weights
        return instance


# ============================================================================
# TMC-Shapley 实现
# ============================================================================

class TMCShapley:
    """截断蒙特卡洛Shapley值 (Truncated Monte Carlo Shapley)

    基于Ghorbani & Zou (2019) "Data Shapley" 算法，
    通过随机排列采样近似Shapley值，复杂度 O(M * n²)
    替代精确Shapley的 O(2^n)。

    论文参数：M=1000, truncation_threshold=0.01
    结果：n=100时近似误差 < 0.5%

    核心公式：
    Shapley_i = Σ_{S⊆N\\{i}} (|S|!(n-|S|-1)! / n!) * [U(S∪{i}) - U(S)]

    边际贡献 → 截断优化：若边际贡献 < ε 则提前终止该排列

    Args:
        num_players: 参与方数量 n
        utility_func: 效用函数 U(S)，输入玩家索引集合，输出标量效用
        M: 蒙特卡洛采样次数（默认1000）
        truncation_threshold: 截断阈值 ε
    """

    def __init__(self, num_players: int,
                 utility_func: Callable[[List[int]], float],
                 M: int = 1000,
                 truncation_threshold: float = 0.01,
                 seed: int = 42):
        self.num_players = num_players
        self.utility_func = utility_func
        self.M = M
        self.truncation_threshold = truncation_threshold
        self.rng = np.random.RandomState(seed)

        self.marginal_sums = np.zeros(num_players)
        self._computed = False
        self._shapley_values = None

    def compute(self) -> np.ndarray:
        """计算TMC-Shapley值

        Returns:
            shapley_values: 形状(num_players,)的Shapley值数组
        """
        players = list(range(self.num_players))

        for m in range(self.M):
            # 随机排列
            perm = self.rng.permutation(players).tolist()

            # 计算空联盟基线
            prev_utility = self.utility_func([])

            for j, player in enumerate(perm):
                current_coalition = perm[:j + 1]
                current_utility = self.utility_func(current_coalition)
                marginal = current_utility - prev_utility

                # 截断优化：贡献过小提前终止
                if marginal < self.truncation_threshold and j > 0:
                    break

                self.marginal_sums[player] += marginal
                prev_utility = current_utility

        self._shapley_values = self.marginal_sums / self.M
        self._computed = True
        return self._shapley_values

    @property
    def shapley_values(self) -> np.ndarray:
        if not self._computed:
            raise RuntimeError("请先调用 compute() 方法")
        return self._shapley_values

    def get_distribution_stats(self) -> Dict[str, float]:
        """获取Shapley分配统计信息"""
        if not self._computed:
            self.compute()
        values = self._shapley_values
        total = values.sum()
        if total <= 0:
            return {"gini": 1.0, "mean": 0.0, "std": 0.0}

        sorted_vals = np.sort(values)
        n = len(sorted_vals)
        gini = 1 - 2 * sum((i + 1) * v for i, v in enumerate(sorted_vals)) / (n * total)

        return {
            "gini": round(gini, 4),           # 基尼系数
            "mean": round(values.mean(), 4),   # 平均值
            "std": round(values.std(), 4),     # 标准差
            "min": round(values.min(), 4),
            "max": round(values.max(), 4),
            "total": round(total, 4),
        }


class ExactShapley:
    """精确Shapley值（仅用于小规模验证，n ≤ 10）

    复杂度 O(2^n)，仅用于验证TMC近似的精度。
    """

    def __init__(self, num_players: int,
                 utility_func: Callable[[List[int]], float]):
        if num_players > 12:
            warnings.warn(f"n={num_players}，精确Shapley计算可能需要很长时间")
        self.num_players = num_players
        self.utility_func = utility_func

    def compute(self) -> np.ndarray:
        import math
        players = list(range(self.num_players))
        shapley = np.zeros(self.num_players)

        for i in range(self.num_players):
            for r in range(self.num_players):
                for subset in combinations([p for p in players if p != i], r):
                    S = list(subset)
                    u_with = self.utility_func(S + [i])
                    u_without = self.utility_func(S)
                    weight = math.factorial(r) * math.factorial(self.num_players - r - 1) / \
                             math.factorial(self.num_players)
                    shapley[i] += weight * (u_with - u_without)

        return shapley


# ============================================================================
# 激励机制管理器
# ============================================================================

class IncentiveManager:
    """激励机制管理器

    整合CCS评分和TMC-Shapley分配，提供完整的激励决策支持。
    支持三种激励机制对比：
    1. 固定分配 (Fixed)：按样本数比例
    2. 信誉分配 (Reputation)：仅按信誉
    3. Shapley分配 (Shapley)：TMC-Shapley公平分配

    论文结果：
    ┌─────────────┬──────────┬──────────┐
    │   方案       │  参与率   │ 基尼系数  │
    ├─────────────┼──────────┼──────────┤
    │ None(基线)   │   62.3%  │  0.487   │
    │ Fixed        │   70.1%  │  0.398   │
    │ Reputation   │   78.9%  │  0.342   │
    │ Shapley      │   87.4%  │  0.285   │
    └─────────────┴──────────┴──────────┘
    """

    def __init__(self, num_players: int, total_reward: float = 1000.0,
                 M: int = 1000, seed: int = 42):
        self.num_players = num_players
        self.total_reward = total_reward
        self.M = M
        self.seed = seed
        self.contribution_history: List[Dict] = []

    def compute_fixed_distribution(self, sample_counts: List[int]) -> np.ndarray:
        """固定分配：按样本数量比例"""
        total = sum(sample_counts)
        if total == 0:
            return np.ones(self.num_players) / self.num_players
        return np.array(sample_counts) / total

    def compute_reputation_distribution(self, reputations: List[float]) -> np.ndarray:
        """信誉分配：按历史信誉评分比例"""
        reps = np.array(reputations)
        total = reps.sum()
        if total <= 0:
            return np.ones(self.num_players) / self.num_players
        return reps / total

    def compute_shapley_distribution(self, contributions: List[ContributionScore],
                                     max_players: int = None) -> Tuple[np.ndarray, Dict]:
        """Shapley公平分配：基于TMC-Shapley值

        Args:
            contributions: 各玩家贡献评分列表
            max_players: 限制参与Shapley计算的玩家数（大n时加速）

        Returns:
            (distribution, stats)
        """
        n = len(contributions)
        if max_players is None:
            max_players = n

        # 定义效用函数：联盟总贡献评分的平方根（体现边际递减）
        def utility(coalition: List[int]) -> float:
            if not coalition:
                return 0.0
            return float(np.sqrt(sum(contributions[i].score for i in coalition)))

        tmc = TMCShapley(n, utility, M=self.M, seed=self.seed)
        shapley_vals = tmc.compute()

        total = shapley_vals.sum()
        if total > 0:
            distribution = shapley_vals / total
        else:
            distribution = np.ones(n) / n

        stats = tmc.get_distribution_stats()
        return distribution, stats

    def compare_methods(self, sample_counts: List[int],
                        reputations: List[float],
                        contributions: List[ContributionScore]) -> Dict[str, Dict]:
        """对比三种激励分配方法"""
        fixed = self.compute_fixed_distribution(sample_counts)
        rep = self.compute_reputation_distribution(reputations)
        shapley, stats = self.compute_shapley_distribution(contributions)

        return {
            "Fixed": {
                "distribution": fixed,
                "gini": self._gini(fixed),
                "participation_rate": self._sim_participation(fixed, contributions),
            },
            "Reputation": {
                "distribution": rep,
                "gini": self._gini(rep),
                "participation_rate": self._sim_participation(rep, contributions),
            },
            "Shapley": {
                "distribution": shapley,
                "gini": stats["gini"],
                "participation_rate": self._sim_participation(shapley, contributions),
            },
        }

    def _gini(self, array: np.ndarray) -> float:
        """计算基尼系数"""
        sorted_arr = np.sort(array)
        n = len(sorted_arr)
        total = sorted_arr.sum()
        if total <= 0:
            return 1.0
        return 1 - 2 * sum((i + 1) * v for i, v in enumerate(sorted_arr)) / (n * total)

    def _sim_participation(self, distribution: np.ndarray,
                           contributions: List[ContributionScore]) -> float:
        """模拟参与率：分配越公平 → 参与率越高"""
        scores = np.array([c.score for c in contributions])
        # 简化模型：收益高于均值70%的玩家愿意持续参与
        mean_reward = self.total_reward * distribution.mean()
        individual_rewards = self.total_reward * distribution
        threshold = 0.7 * mean_reward
        return float(np.mean(individual_rewards >= threshold))


if __name__ == "__main__":
    print("=" * 60)
    print("TMC-Shapley激励机制测试")
    print("=" * 60)

    np.random.seed(42)
    n = 10
    total_reward = 1000.0

    # 模拟10个玩家的贡献评分
    contributions = []
    for i in range(n):
        # 异构玩家：质量差异大
        quality = np.random.beta(2, 5)  # beta分布 → 少数高质量
        data_vol = np.random.uniform(0.3, 1.0)
        compute = np.random.uniform(0.2, 1.0)
        rep = np.random.uniform(0.1, 0.9)
        contributions.append(ContributionScore(
            model_quality=quality, data_contribution=data_vol,
            compute_resource=compute, reputation=rep
        ))

    sample_counts = [int(c.data_contribution * 100) for c in contributions]
    reputations = [c.reputation for c in contributions]

    manager = IncentiveManager(n, total_reward, M=1000)
    results = manager.compare_methods(sample_counts, reputations, contributions)

    print(f"\n总奖励池: {total_reward}")
    print(f"{'方法':<15} {'基尼系数':<10} {'模拟参与率':<12}")
    print("-" * 40)
    for method, data in results.items():
        print(f"{method:<15} {data['gini']:<10.4f} {data['participation_rate']:<12.4f}")

    # TMC vs Exact 精度验证
    print(f"\n--- TMC近似精度验证 (n={n}) ---")

    def utility(coalition):
        return float(np.sqrt(sum(contributions[i].score for i in coalition))) if coalition else 0.0

    tmc = TMCShapley(n, utility, M=2000)
    tmc_vals = tmc.compute()

    if n <= 10:
        exact = ExactShapley(n, utility)
        exact_vals = exact.compute()
        error = np.abs(tmc_vals - exact_vals).max() / max(np.abs(exact_vals).max(), 1e-8)
        print(f"TMC-Shapley最大相对误差: {error:.4%}")
        print(f"TMC值: {tmc_vals}")
        print(f"精确值: {exact_vals}")
