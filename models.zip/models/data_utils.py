# ============================================================================
# data_utils.py — 数据处理与Dirichlet Non-IID划分模块
# ============================================================================
# 功能：MNIST/CIFAR数据集加载、Dirichlet分布Non-IID划分、数据加载器构建
# 参考：论文H1假设验证 — Non-IID环境下所提方法较FedAvg提升3.17pp
# ============================================================================

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Subset
from torchvision import datasets, transforms
from collections import defaultdict
from typing import Tuple, List, Dict, Optional
import random


def set_seed(seed: int = 42):
    """固定随机种子，保证实验可复现"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def load_dataset(name: str, data_dir: str = "./data") -> Tuple[Dataset, Dataset, dict]:
    """加载学术基准数据集

    Args:
        name: 数据集名称 {"MNIST", "Fashion-MNIST", "CIFAR-10", "CIFAR-100"}
        data_dir: 数据存储目录

    Returns:
        (train_dataset, test_dataset, info_dict)
        info_dict: {"num_classes": int, "input_shape": tuple, "task": str}
    """
    dataset_config = {
        "MNIST": {
            "loader": datasets.MNIST,
            "transform": transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.1307,), (0.3081,))
            ]),
            "num_classes": 10, "input_shape": (1, 28, 28), "task": "classification"
        },
        "Fashion-MNIST": {
            "loader": datasets.FashionMNIST,
            "transform": transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.2860,), (0.3530,))
            ]),
            "num_classes": 10, "input_shape": (1, 28, 28), "task": "classification"
        },
        "CIFAR-10": {
            "loader": datasets.CIFAR10,
            "transform": transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465),
                                     (0.2470, 0.2435, 0.2616))
            ]),
            "num_classes": 10, "input_shape": (3, 32, 32), "task": "classification"
        },
        "CIFAR-100": {
            "loader": datasets.CIFAR100,
            "transform": transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5071, 0.4865, 0.4409),
                                     (0.2673, 0.2564, 0.2762))
            ]),
            "num_classes": 100, "input_shape": (3, 32, 32), "task": "classification"
        },
    }

    if name not in dataset_config:
        raise ValueError(f"未知数据集: {name}. 支持: {list(dataset_config.keys())}")

    cfg = dataset_config[name]
    train_dataset = cfg["loader"](data_dir, train=True, download=True, transform=cfg["transform"])
    test_dataset = cfg["loader"](data_dir, train=False, download=True, transform=cfg["transform"])

    info = {"num_classes": cfg["num_classes"], "input_shape": cfg["input_shape"], "task": cfg["task"]}
    return train_dataset, test_dataset, info


def dirichlet_partition(labels: np.ndarray, num_clients: int, alpha: float,
                        seed: int = 42) -> List[List[int]]:
    """基于Dirichlet分布的Non-IID数据划分

    使用Dirichlet分布对标签进行非均匀分配，模拟工业场景中各企业数据异构分布。
    alpha越小 → 分布越不均匀（高度Non-IID）
    alpha越大 → 分布趋近均匀（接近IID）

    论文实验: α ∈ {0.1 (高度Non-IID), 0.5 (中度Non-IID)}

    Args:
        labels: 所有样本的标签数组, shape=(N,)
        num_clients: 客户端数量 n ∈ {10, 50, 100}
        alpha: Dirichlet浓度参数，论文使用α=0.1(高度)/0.5(中度)
        seed: 随机种子

    Returns:
        List[List[int]]: 每个客户端的样本索引列表
    """
    rng = np.random.RandomState(seed)
    num_classes = len(np.unique(labels))
    class_indices = [np.where(labels == c)[0] for c in range(num_classes)]

    client_indices = [[] for _ in range(num_clients)]

    for c in range(num_classes):
        # Dirichlet分布生成每个客户端在该类别上的分配比例
        proportions = rng.dirichlet(np.repeat(alpha, num_clients))
        # 按比例分配样本
        proportions = np.array([p * len(class_indices[c]) for p in proportions])
        proportions = proportions.astype(int)
        # 余数随机分配
        remainder = len(class_indices[c]) - proportions.sum()
        for i in range(remainder):
            proportions[i % num_clients] += 1

        # 打乱并分配
        shuffled = rng.permutation(class_indices[c])
        start = 0
        for client_id in range(num_clients):
            count = proportions[client_id]
            client_indices[client_id].extend(shuffled[start:start + count].tolist())
            start += count

    # 每个客户端内部打乱
    for client_id in range(num_clients):
        rng.shuffle(client_indices[client_id])

    return client_indices


def create_client_loaders(train_dataset: Dataset, test_dataset: Dataset,
                          client_indices: List[List[int]],
                          batch_size: int = 32) -> Tuple[List[DataLoader], DataLoader]:
    """为每个客户端创建训练DataLoader，以及全局测试DataLoader

    Args:
        train_dataset: 完整训练集
        test_dataset: 完整测试集
        client_indices: dirichlet_partition的输出
        batch_size: 批次大小

    Returns:
        (client_train_loaders, global_test_loader)
    """
    client_loaders = []
    for indices in client_indices:
        subset = Subset(train_dataset, indices)
        loader = DataLoader(subset, batch_size=batch_size, shuffle=True, num_workers=0)
        client_loaders.append(loader)

    test_loader = DataLoader(test_dataset, batch_size=batch_size * 2, shuffle=False, num_workers=0)
    return client_loaders, test_loader


def analyze_partition(client_indices: List[List[int]], labels: np.ndarray,
                      num_classes: int) -> Dict:
    """分析Non-IID划分的统计特征

    Returns:
        dict: {"client_class_dist": 每个客户端各类别样本数,
               "gini_per_client": 每个客户端类别Gini系数}
    """
    client_class_dist = []
    for indices in client_indices:
        client_labels = labels[indices]
        dist = [np.sum(client_labels == c) for c in range(num_classes)]
        client_class_dist.append(dist)

    gini_per_client = []
    for dist in client_class_dist:
        total = sum(dist)
        if total == 0:
            gini_per_client.append(0)
            continue
        sorted_dist = sorted(dist)
        gini = 1 - 2 * sum((i + 1) * v for i, v in enumerate(sorted_dist)) / (len(dist) * total)
        gini_per_client.append(gini)

    return {
        "client_class_dist": client_class_dist,
        "gini_per_client": gini_per_client,
        "mean_gini": np.mean(gini_per_client),
        "std_gini": np.std(gini_per_client),
    }


if __name__ == "__main__":
    set_seed(42)
    print("=" * 60)
    print("数据工具模块测试")
    print("=" * 60)

    for ds_name in ["MNIST", "CIFAR-10"]:
        train_ds, test_ds, info = load_dataset(ds_name)
        labels = np.array(train_ds.targets)

        for alpha in [0.1, 0.5]:
            indices = dirichlet_partition(labels, num_clients=10, alpha=alpha)
            stats = analyze_partition(indices, labels, info["num_classes"])
            print(f"\n{ds_name} | α={alpha} | 客户端数=10")
            print(f"  平均Gini系数: {stats['mean_gini']:.4f} ± {stats['std_gini']:.4f}")
            print(f"  客户端0样本分布: {stats['client_class_dist'][0]}")
