# ============================================================================
# smpc_aggregation.py — 安全多方计算(SMPC)聚合模块
# ============================================================================
# 功能：基于秘密共享的安全多方计算聚合，支持SPDZ协议族
#       在联邦学习场景中，多方各自持有梯度，在不泄露个体信息前提下计算聚合结果
# 论文结果：SMPC+DP(ε=1.0)联合方案 → MIA攻击成功率降至9.6%, 准确率79.43%
# ============================================================================

import numpy as np
import torch
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass
import hashlib
import secrets
import time


# ============================================================================
# 秘密共享原语 (Shamir Secret Sharing → Additive Secret Sharing)
# ============================================================================

class AdditiveSecretSharing:
    """加法秘密共享 (Additive Secret Sharing)

    原理：将数值x分解为n份随机份额{s_1, ..., s_n}，满足 Σs_i = x
    在模p有限域上进行运算，保证信息论安全。

    安全性：任何n-1方合谋无法恢复原始值（完全信息论安全）
    """

    def __init__(self, num_parties: int, prime: int = None):
        """
        Args:
            num_parties: 参与方数量
            prime: 有限域模数，默认为2^31-1（Mersenne素数）
        """
        self.num_parties = num_parties
        self.prime = prime if prime else 2**31 - 1  # Mersenne prime

    def share(self, value: float, scale: int = 10**6) -> np.ndarray:
        """将浮点数值分解为秘密份额

        Args:
            value: 待分享的原始值
            scale: 定点数缩放因子

        Returns:
            shares: 形状(num_parties,)的秘密份额数组
        """
        # 转为定点整数
        int_value = int(round(value * scale)) % self.prime
        # 生成n-1个随机份额
        shares = np.array([secrets.randbelow(self.prime) for _ in range(self.num_parties - 1)])
        # 最后一个份额确保总和等于原始值
        last_share = (int_value - shares.sum()) % self.prime
        shares = np.append(shares, last_share)
        return shares

    def reconstruct(self, shares: np.ndarray, scale: int = 10**6) -> float:
        """从秘密份额重建原始值

        Args:
            shares: 所有份额
            scale: 定点数缩放因子

        Returns:
            重建的浮点数值
        """
        total = int(shares.sum()) % self.prime
        # 处理负数
        if total > self.prime // 2:
            total -= self.prime
        return total / scale

    def secure_add(self, shares_a: np.ndarray, shares_b: np.ndarray) -> np.ndarray:
        """安全加法：各方本地相加即可（无需通信）"""
        return (shares_a + shares_b) % self.prime

    def secure_scalar_mul(self, shares: np.ndarray, scalar: float,
                          scale: int = 10**6) -> np.ndarray:
        """安全标量乘法：各方本地乘以标量"""
        int_scalar = int(round(scalar * scale)) % self.prime
        return (shares * int_scalar) % self.prime


# ============================================================================
# SMPC聚合器
# ============================================================================

@dataclass
class PartyContribution:
    """单个参与方的贡献"""
    party_id: int
    gradients: List[torch.Tensor]  # 模型梯度列表
    num_samples: int
    label_distribution: Optional[np.ndarray] = None


class SMPCAggregator:
    """安全多方计算聚合器

    模拟SPDZ协议的离线-在线双阶段执行：
    1. 离线阶段：生成乘法三元组(Beaver Triples)和随机份额
    2. 在线阶段：各方输入秘密份额，执行安全聚合计算

    论文结果：SMPC+DP(ε=1.0)联合 → MIA成功率降至9.6%，准确率79.43%

    注意：完整SPDZ协议需要MP-SPDZ框架，本模块实现了
          核心秘密共享+安全聚合的Python模拟版本，
          用于实验验证和概念演示。
    """

    def __init__(self, num_parties: int, prime: int = None):
        """
        Args:
            num_parties: 参与方数量
            prime: 有限域模数
        """
        self.num_parties = num_parties
        self.ass = AdditiveSecretSharing(num_parties, prime)
        self.prime = self.ass.prime
        self.scale = 10**6
        # 通信开销统计
        self.communication_cost = 0  # 字节
        self.offline_time = 0.0
        self.online_time = 0.0

    def _tensor_to_flat(self, tensors: List[torch.Tensor]) -> np.ndarray:
        """将梯度列表展平为一维数组"""
        flat = np.concatenate([t.detach().cpu().numpy().ravel() for t in tensors])
        return flat

    def _flat_to_tensors(self, flat: np.ndarray,
                         template: List[torch.Tensor]) -> List[torch.Tensor]:
        """将一维数组还原为梯度列表"""
        result = []
        offset = 0
        for t in template:
            size = t.numel()
            chunk = flat[offset:offset + size].reshape(t.shape)
            result.append(torch.tensor(chunk, dtype=t.dtype))
            offset += size
        return result

    def aggregate(self, contributions: List[PartyContribution],
                  weights: Optional[List[float]] = None) -> List[torch.Tensor]:
        """SMPC安全聚合主流程

        模拟SPDZ在线阶段执行：
        1. 各方对梯度进行秘密共享
        2. 在秘密共享域进行加权求和
        3. 重建聚合结果

        Args:
            contributions: 各参与方的梯度贡献
            weights: 各参与方的聚合权重（默认按样本数）

        Returns:
            聚合后的模型梯度列表
        """
        if len(contributions) == 0:
            raise ValueError("至少需要一个参与方")

        t_start_online = time.time()
        template = contributions[0].gradients
        total_samples = sum(c.num_samples for c in contributions)

        # 默认权重：按样本数比例
        if weights is None:
            weights = [c.num_samples / total_samples for c in contributions]

        # 获取展平梯度
        flat_gradients = [self._tensor_to_flat(c.gradients) for c in contributions]

        # 在秘密共享域执行加权聚合
        # 模拟各方独立产生份额并交互
        all_shares = []
        for i, flat_grad in enumerate(flat_gradients):
            # 加权后的梯度
            weighted = flat_grad * weights[i]
            shares = np.array([
                self.ass.share(v) for v in weighted
            ])  # shape: (n_params, n_parties)
            all_shares.append(shares)
            # 通信开销：每方发送n-1份份额
            self.communication_cost += (self.num_parties - 1) * flat_grad.nbytes

        # 各方本地求和（安全加法）
        aggregated_shares = np.zeros_like(all_shares[0])
        for shares in all_shares:
            aggregated_shares = (aggregated_shares + shares) % self.prime

        # 重建聚合结果
        aggregated_flat = np.array([
            self.ass.reconstruct(
                aggregated_shares[i]  # 每个参数位置的n方份额
            ) for i in range(aggregated_shares.shape[0])
        ])

        self.online_time = time.time() - t_start_online
        return self._flat_to_tensors(aggregated_flat, template)

    def get_stats(self) -> Dict[str, float]:
        """获取SMPC执行统计"""
        return {
            "num_parties": self.num_parties,
            "prime": self.prime,
            "scale": self.scale,
            "communication_bytes": self.communication_cost,
            "communication_mb": self.communication_cost / (1024 * 1024),
            "online_time_s": self.online_time,
        }


class SMPCSimulator:
    """SMPC完整模拟器 — 结合DP的联邦学习安全聚合

    论文实验流程：
    1. 各客户端本地进行DP-SGD训练
    2. 对DP梯度进行秘密共享
    3. 通过SMPC安全聚合所有梯度
    4. 重建全局模型
    """

    def __init__(self, num_parties: int = 10):
        self.num_parties = num_parties
        self.aggregator = SMPCAggregator(num_parties)

    def simulate_round(self, gradients_list: List[List[torch.Tensor]],
                       num_samples_list: List[int]) -> Tuple[List[torch.Tensor], Dict]:
        """模拟一轮SMPC安全聚合

        Args:
            gradients_list: 各参与方的梯度列表
            num_samples_list: 各参与方的样本数

        Returns:
            (aggregated_gradient, stats)
        """
        contributions = []
        for i, (grads, ns) in enumerate(zip(gradients_list, num_samples_list)):
            contributions.append(PartyContribution(
                party_id=i,
                gradients=grads,
                num_samples=ns,
            ))

        aggregated = self.aggregator.aggregate(contributions)
        stats = self.aggregator.get_stats()
        stats["num_contributions"] = len(contributions)
        return aggregated, stats


if __name__ == "__main__":
    print("=" * 60)
    print("SMPC安全聚合模块测试")
    print("=" * 60)

    # 模拟3方安全聚合
    n_parties = 3
    dim = 1000

    # 生成随机梯度
    gradients_list = []
    num_samples_list = [100, 150, 250]
    for i in range(n_parties):
        grads = [torch.randn(dim) * (0.5 + 0.5 * i) for _ in range(2)]
        gradients_list.append(grads)

    simulator = SMPCSimulator(num_parties=n_parties)
    aggregated, stats = simulator.simulate_round(gradients_list, num_samples_list)

    print(f"\n参与方: {n_parties}, 梯度维度: {dim}")
    print(f"通信开销: {stats['communication_mb']:.2f} MB")
    print(f"在线时间: {stats['online_time_s']:.4f} s")
    print(f"聚合结果(前10维): {aggregated[0][:10].tolist()}")

    # 验证正确性：明文加权平均 vs SMPC安全聚合
    total_samples = sum(num_samples_list)
    plain_avg = sum(g[0] * (ns / total_samples) for g, ns in zip(gradients_list, num_samples_list))
    diff = (aggregated[0] - plain_avg).abs().max().item()
    print(f"\n与明文聚合的最大误差: {diff:.6f}")
    print("✓ SMPC聚合正确！" if diff < 1e-3 else "✗ 误差过大！")
